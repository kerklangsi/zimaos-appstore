# Sync History: GitHub Runner Manager (`github-runner`)

> Upstream Source: https://github.com/kerklangsi/github-runner

## [3.2.0] - 2026-09-26 14:43:05 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-26 14:42:41 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-26 14:39:08 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Updated README.md (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.0.0] - 2026-09-26 14:06:02 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner-docker:latest`
- **Category**: `Developer Tools`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6024 chars)
- **Source**: https://github.com/kerklangsi/github-runner

## [3.0.0] - 2026-09-26 10:45:49 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner-docker:latest`
- **Category**: `Developer Tools`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6024 chars)
- **Source**: https://github.com/kerklangsi/github-runner-docker
