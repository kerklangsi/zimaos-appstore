# Sync History: GitHub Runner Manager (`github-runner`)

> Upstream Source: https://github.com/kerklangsi/github-runner

## [3.2.0] - 2026-09-29 17:25:19 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-29 11:54:52 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-29 03:36:28 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-28 22:49:48 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner

## [3.2.0] - 2026-09-28 12:33:49 UTC
### Action: Created / Updated
- **Image**: `kerklangsi/github-runner:latest`
- **Category**: `AI`
- **Compose**: Updated docker-compose.yml
- **Icon**: icon.svg (Existing local icon)
- **Screenshots**: 3 existing image(s) in picture/
- **README**: Up-to-date (6049 chars)
- **Source**: https://hub.docker.com/r/kerklangsi/github-runner
